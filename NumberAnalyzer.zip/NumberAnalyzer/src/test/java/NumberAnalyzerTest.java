import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NumberAnalyzerTest {

    // Issue 1: Statement coverage
    @Test
    void testSumEvenNumbersWithEvenInput() {
        assertEquals(6, NumberAnalyzer.sumEvenNumbers(5));
    }

    @Test
    void testNegativeInputThrowsException() {
        assertThrows(
            IllegalArgumentException.class,
            () -> NumberAnalyzer.sumEvenNumbers(-1)
        );
    }

    // Issue 2: Branch/path-oriented test cases
    @Test
    void testZeroInputSkipsLoop() {
        assertEquals(0, NumberAnalyzer.sumEvenNumbers(0));
    }

    @Test
    void testOddInput() {
        assertEquals(0, NumberAnalyzer.sumEvenNumbers(1));
    }

    @Test
    void testEvenInput() {
        assertEquals(2, NumberAnalyzer.sumEvenNumbers(2));
    }

    @Test
    void testMultipleLoopIterations() {
        assertEquals(12, NumberAnalyzer.sumEvenNumbers(6));
    }
}
