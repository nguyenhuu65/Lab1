public class NumberAnalyzer {

    public static int sumEvenNumbers(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("n must be non-negative");
        }

        int sum = 0;

        for (int i = 1; i <= n; i++) {
            if (i % 2 == 0) {
                sum += i;
            }
        }

        return sum;
    }

    public static void main(String[] args) {
        int n = 10;
        int result = sumEvenNumbers(n);

        System.out.println(
            "Sum of even numbers from 1 to " + n + " = " + result
        );
    }
}
