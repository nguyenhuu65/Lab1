# NumberAnalyzer

A simple Java Maven project used to practice JUnit 5 statement coverage and path/branch-oriented testing.

## Requirements
- JDK 17 or newer
- Maven 3.8+

## Run the program
```bash
mvn compile
java -cp target/classes NumberAnalyzer
```

Expected output:
```text
Sum of even numbers from 1 to 10 = 30
```

## Run JUnit tests
```bash
mvn clean test
```

## GitHub workflow for the assignment
1. Commit the program and `pom.xml` first.
2. Create an issue for JUnit statement coverage.
3. Add the first tests and commit them while referencing the first issue.
4. Create an issue for path coverage.
5. Add the additional tests and commit them while referencing the second issue.

Note: exhaustive path coverage is not generally possible for a loop with an unrestricted number of iterations. The tests exercise representative loop cases and both outcomes of the conditional branches.
